# spark-minio-handler

PyPI project: https://pypi.org/project/SparkMinIOHandle/

Esta biblioteca tem a intenção de facilitar o uso da biblioteca [PySpark](https://spark.apache.org/docs/latest/api/python/) em conjunto com o Object Storage [MinIO](https://min.io/).

# Instalação

````
pip install SparkMinIOHandle
````

